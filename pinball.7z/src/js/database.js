PINBALL.call = function(){


    /**
     * Zapis danych
     * 
     * @param {int} $score 
     * @param {string} $token 
     */
    function save($score, $token){

        var http = new XMLHttpRequest();
       
        var url = "complete.php";
        var str = "score=" + $score + "&token=" + $token;
        var params = encodeURI(str);
        http.open("POST", url, true);
    
        //Send the proper header information along with the request
        http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        http.setRequestHeader("Content-length", params.length);
        http.setRequestHeader("Connection", "close");
        answer= "";
        http.onreadystatechange = function () {//Call a function when the state changes.
            if (http.readyState == 4 && http.status == 200) {
                answer = "ok";
            }
        }
        http.send(params);
    }


    return {
        save : save,
    }
}();