
$(document).ready(function(){
 
    PINBALL.game.triggerEvents();
   // PINBALL.game.init();
});
