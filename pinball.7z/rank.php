<!DOCTYPE html>
<?php
$ini_array = parse_ini_file("config/config.ini");
$mysqli = new mysqli($ini_array['host'], $ini_array['user'], $ini_array['password'], $ini_array['base']);

if ($mysqli->connect_errno) {
    throw new Exception("Failed to connect");
    header('Content-type:application/json;charset=utf-8');
    echo json_encode(array('message' => 'error'));
    exit;
}


$top = array();
$sql = "SELECT * FROM scores WHERE !ISNULL(score) AND !ISNULL(name) order by score DESC limit 10";

$results = $mysqli->query($sql);
while ($row = $results->fetch_assoc()) {
    $top[] = $row;
}
$mysqli->close();

$url = "/multi-multi/poznaj-swoje-liczby";
if (strpos($_SERVER['SERVER_NAME'], "test") !== false) {
    $url = "/";
}

?>
<html>

<head>
    <meta charset="UTF-8" />
    <meta content="width=device-width, initial-scale=1.0"
      name="viewport"/>
    <title>Multi Multi Pinball</title>
    <style>
        canvas {
            width: inherit;
            height: inherit;
        }
    </style>
    <link rel="stylesheet" href="dist/style.css">

</head>

<body style="overflow-y: hidden;">
    <div style="max-width: 378px;height: 823px; margin: 0 auto; position:relative" id="lotto-pinball">
        <div class="sim-container" id="first-slide-container">
            <div id="multi-container" class="multi-container">
                <div id="multi-panel" class="multi-panel" style="position: relative;">
                    <div class="container" id="results-slide">

                     <div class="mm-top-text">
                                Najlepsi gracze:
                            </div>
                            <?php
                            if (!empty($top)) { ?>
                        <table class="rank-table"> 
                                <tbody>
            
                          <?php
                            $i = 1;
                            foreach ($top as $result) {
                                echo '<tr>';
                                echo '<td><p class="mm-medium-text">' . $i . '.</p></td>';
                                echo '<td><p class="mm-medium-text">' . $result['name'] . '</p></td>';
                                echo '<td><p class="mm-medium-text">' . $result['score'] . 'pkt.</p></td>';
                                echo '</tr>';
                                $i++;

                            }
                            ?>
                                </tbody>
                            </table>

                <?php

            } else {
                echo '<p class="mm-medium-text">Brak wyników</p>';
            }
            ?>
            <a class="btn-printer-end" href="<?= $url ?>" style="margin-top: 15px;display:block;text-decoration:none">
                Zagraj ponownie
            </a>
                       </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>